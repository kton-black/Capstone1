import pygame
import configparser
import sys

class Scrabble_Board(object):

    def __init__(self):
        pygame.init()

        # define constants for the window size and grid size
        self.WINDOW_SIZE = (600, 600)
        self.GRID_SIZE = 15

        # define colors for the grid and score spaces
        WHITE = (255, 255, 255)
        BLACK = (0, 0, 0)
        RED = (255, 0, 0)
        LIGHT_RED = (255,200,200)
        BLUE = (0, 0, 255)
        LIGHT_BLUE = (200,200,255)

        # create the window and set its title
        win = pygame.display.set_mode(self.WINDOW_SIZE)
        pygame.display.set_caption("Scrabble Board")

        # draw the grid squares on the window
        square_size = self.WINDOW_SIZE[0] // self.GRID_SIZE
        for row in range(self.GRID_SIZE):
            for col in range(self.GRID_SIZE):
                x = col * square_size
                y = row * square_size
                rect = pygame.Rect(x, y, square_size, square_size)

                # fill the square with white
                pygame.draw.rect(win, WHITE, rect)

                # draw light blue squares on double-letter
                if (row, col) in [(0, 3), (0, 11), (2, 6), (2, 8),
                                  (3, 0), (3, 7), (3, 14), (6, 2),
                                  (6, 6), (6, 8), (6, 12), (7, 3),
                                  (7, 11), (8, 2), (8, 6), (8, 8),
                                  (8, 12), (11, 0), (11, 7), (11, 14),
                                  (12, 6), (12, 8), (14, 3), (14, 11)]:
                    pygame.draw.rect(win, LIGHT_BLUE, rect)

                # draw light red squares on double-word
                elif (row, col) in [(1, 1), (1, 13), (2, 2), (2, 12),
                                    (3, 3), (3, 11), (4, 4), (4, 10),
                                    (10, 4), (10, 10), (11, 3), (11, 11),
                                    (12, 2), (12, 12), (13, 1), (13, 13)]:
                    pygame.draw.rect(win, LIGHT_RED, rect)

                # draw blue squares on triple-letter
                elif (row, col) in [(1, 5), (1, 9), (5, 1), (5, 5), (5, 9), (5, 13),
                                    (9, 1), (9, 5), (9, 9), (9, 13), (13, 5), (13, 9)]:
                    pygame.draw.rect(win, BLUE, rect)

                # draw red squares on triple-word
                elif (row, col) in [(0, 0), (0, 7), (0, 14), (7, 0), (7, 14), (14, 0), (14, 7), (14, 14)]:
                    pygame.draw.rect(win, RED, rect)

                pygame.draw.rect(win, BLACK, rect, width=1)

        # update the display and run the game loop
        pygame.display.update()
        self.load_file()

    def start(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

    def load_file(self, file="board.ini"):
        self.board = []
        self.key = {}
        parser = configparser.ConfigParser()
        parser.read(file)
        #self.tileset = parser.get("board","image")
        # print(parser['board'])
        # self.board = parser.get("board","start").split("\n")
        print(parser.sections())
        for section in parser.sections():
            if len(section) == 1:
                desc = dict(parser.items(section))
                print(desc)
                self.key[section] = desc
        # self.width = len(self.board[0])
        # self.height = len(self.board)
        # print(self.board)
        print(self.key)
        # print(self.width)
        # print(self.height)

    def get_tile(self, x, y):
        try:
            char = self.board[y][x]
        except IndexError:
            return {}
        try:
            return self.key[char]
        except KeyError:
            return {}

